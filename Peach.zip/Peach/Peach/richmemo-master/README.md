# RichMemo
The LCL rich-text editing component based on system native components.

Wiki: https://wiki.freepascal.org/RichMemo

The old Lazaruz-CCR RichMemo repository is now considered to be closed.
