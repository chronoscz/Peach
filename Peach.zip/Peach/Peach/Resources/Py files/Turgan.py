import os
import io
import sys
import random
import types
import traceback

brackets = {}
_fetched = []
_notes = ""
_note_count = 0

def note(s):
    global _notes, _note_count
    _note_count = _note_count + 1
    _notes = _notes + "("+str(_note_count)+") "+str(s)+"   "

def ends_with(*args):
    flag = False
    for i in range(1,len(args)):
        if type(args[i]) == list:
           for j in range(0,len(args[i])):
               flag = flag or args[0].endswith(args[i][j])
        else:
            flag = flag or args[0].endswith(args[i])
    return flag


def starts_with(*args):
    flag = False
    for i in range(1,len(args)):
        if type(args[i]) == list:
           for j in range(0,len(args[i])):
               flag = flag or args[0].startswith(args[i][j])
        else:
            flag = flag or args[0].startswith(args[i])
    return flag

def sequence(*args):
    if type(args[0]) == list:
        S = args[0]
    else:
        S = [args[0]]
    if len(args) == 1:
        return S
    L = []
    for i in S:
        for k in sequence(*args[1:]):
            L.append(i + k)
    return L

def merge_dictionaries(D1, D2):
    for i in D2.keys():
        if i in D1.keys():
            D1[i] = D1[i] + D2[i]
        else:
            D1[i] = D2[i]
    return D1

class Entry:
    def __init__(self,dir,E,L):
        global brackets
        self.directive = dir
        self._semicolon=[-1,-1]
        self.words = ["",""]
        self.brackets = []
        for i in range(0,2):
            T = _strip_brackets(E[i])
            self.words[i] = T[0]
            self._semicolon[i] = T[1]
            self.brackets = self.brackets + T[2]
            brackets = merge_dictionaries(brackets,T[3])
        if dir != "":
            self.brackets = self.brackets + [dir[1:-1]]

def has(s,t):
    for x in brackets[s]:
        if x[:len(t)+1] == t+" ":
            return True
    return False

def what_is(s,t):
    for x in brackets[s]:
        if x[:len(t)+1] == t+" ":
            return x[len(t)+1:]
    raise LookupError("what_is("+s+","+t+") : word "+s+" has no "+t)

def fetch(s):
    global _fetched, _selected
    if not _topic:
        raise LookupError("fetch("+s+") : topic is empty or unselected.")
    possible = [x for x in range(0,len(_topic)) if s in _topic[x].brackets]
    if not possible:
        raise LookupError("fetch("+s+") : topic does not contain entry of type "+s)
    if _selected in possible and not _selected in _fetched:
        _fetched.append(_selected)
        return _topic[_selected]
    for x in possible:
        if x in _fetched:
            possible.remove(x)
    if not possible:
        raise LookupError("fetch("+s+") : you have used all the things of type "+s)
    temp = random.choice(possible)
    _fetched.append(temp) 
    return _topic[temp]

def there_is(s, n = 1):
    if not _topic:
        raise LookupError("there_is("+s+") : topic is empty or unselected")
    possible = [x for x in range(0,len(_topic)) if s in _topic[x].brackets]
    for x in possible:
        if x in _fetched:
            possible.remove(x)    
    return len(possible) >= n

def from_table(r,c,T):
    if T[0].count(c) == 0:
        raise LookupError("from_table : "+c+" does not identify a column.")
    x = T[0].index(c)
    for row in T:
        if row[0] == r:
            return row[x+1]
    raise LookupError("from_table : "+r+" does not identify a row.")

def make_index(Y):
    ix = set()
    for y in Y:
        if type(y) is list and not isinstance(y[0], types.FunctionType):
            ix.add(y[0])
        ix = ix | make_index(y[2:])
    return ix

def standard_format(prefix, capitalize, postfix):
    def the_format(s):
        if prefix or capitalize:
            first_space = s.find(" ")
            if first_space == -1:
                first_space = len(s)
            r = ""
            for i in range(first_space):
                t = s[i:i+1]
                if i == 0 or (s[i-1:i] == '/'):
                   if capitalize:
                        t = t.capitalize()
                   t = prefix+t
                r = r + t
            s = r + s[first_space:]
        if postfix:
            last_space = s.rfind(" ")
            r = ""
            for i in range(last_space,len(s)+1):
                t = s[i:i+1]
                if i == len(s) or (t == '/'):
                    t = postfix + t
                r = r + t
            s = s[:last_space] + r
        return s
    return the_format

def grammar(lang,*X):
    ix = list(make_index(X))
    n = [0] * len(ix)
    if not n:
       return "".join(list(X)) 

    def evaluate(L):
        for i in range(0,len(L)):
            if type(L[i]) is list:
                if isinstance(L[i][0], types.FunctionType):
                    L[i] = L[i][0](*evaluate(L[i][1:]))
                else:
                    if len(L[i]) == 1:
                        L[i] = L[i][0].words[lang][n[ix.index(L[i][0])]]
                    else:
                        L[i] = L[i][1](L[i][0].words[lang][n[ix.index(L[i][0])]],*evaluate(L[i][2:]))
        return L

    s = ""
    h = ""
    while n[len(n)-1]<len(ix[len(n)-1].words[lang]):
        T = list(X)
        t = "".join(evaluate(T))
        t = format[lang](t)
        if all([ix[i]._semicolon[lang] == -1 or
                n[i] <= ix[i]._semicolon[lang]
                for i in range(0,len(n))]):
            if s:
                s = s + ", "
            s = s + t
        else:
            if h:
                h = h + ", "
            h = h + t
        p = 0
        flag = True
        while flag:
            n[p] = n[p] + 1
            flag = (n[p] == len(ix[p].words[lang]))
            if flag and p < len(n)-1:
                n[p] = 0
                p = p + 1
    if h:
        s = s + "; " + h
    result[lang] = s

def _strip_brackets(s):
    bs = ["(","[","{"]
    bf = [")","]","}"]
    bc = [0] * len(bs)
    sc = -1
    ic = 0
    t = ""
    u = ""
    L = []
    B = []
    D = {}
    H = []
    for i in range(0,len(s)):
        c = s[i]
        if c in bs:
            bc[bs.index(c)] = bc[bs.index(c)] + 1
        if sum(bc) == 0:
            if c == ";":
                if sc == -1:
                    sc = ic
                c = ","
            if c != "," and not (c in bs) and not (c in bf):
                t = t + c
            if c == "," or i == len(s)-1:
                ic = ic + 1
                t = t.rstrip().lstrip()
                L.append(t)
                D[t] = B
                H = H + B
                B = []
                t = ""
        else:
            if c in bf and bc[bf.index(c)] > 0:
                bc[bf.index(c)] = bc[bf.index(c)] - 1
            if sum(bc) == 0:
                B.extend(u.split(", "))
                u = ""
                if i == len(s)-1:
                    t = t.rstrip().lstrip()
                    L.append(t)
                    H = H + B
                    D[t] = B
            else:
                if not c in bs:
                    u = u + c
    return L, sc, H, D

def unchanged(s):
    return s

current_directory = os.getcwd()
try:
    os.chdir(current_directory+"\Resources\File transfer")
except(FileNotFoundError):
    current_directory = current_directory + '\Peach'
    os.chdir(current_directory+"\Resources\File transfer")

with io.open("patopy.rsc", "r", encoding="utf-8") as file:
    _data_in = file.readlines()

_data_in = [item.rstrip() for item in _data_in]

if _data_in[1] ==_data_in[2]:
  _data_in[2] = _data_in[2] +"B"
if _data_in[1] == "":
   _data_in[1] = "A"

question_language = int(_data_in[3])
questions = _data_in[4]
answers = _data_in[5]

_selected = int(_data_in[6])

entry = Entry(_data_in[7+_selected*3],[_data_in[8+_selected*3],_data_in[9+_selected*3]],[_data_in[1],_data_in[2]])

_topic = []
for i in range(0,(len(_data_in) - 7)//3):
        _topic = _topic + [Entry(_data_in[3*i+7],[_data_in[3*i+8],_data_in[3*i+9]],[_data_in[1],_data_in[2]])]

topic_directive = _data_in[0]
exec(_data_in[1].replace(' ', '_') + " = 0")
exec(_data_in[2].replace(' ', '_') + " = 1")
result = ["",""]
result[0] = _data_in[8+_selected*3]
result[1] = _data_in[9+_selected*3]
directive = ""
_error_report = ""
_error_line = '-1'
format = [unchanged,unchanged]

try:
    fdic1 = {
    	"f": "ᚠ",
    	"u": "ᚢ",	
    	"a": "ᚨ",
    	"r": "ᚱ",
    	"k": "ᚳ",
    	"’": "ᚲ",
    	"g": "ᚷ",
    	"h": "ᚺ",
    	"n": "ᚾ",
    	"i": "ᛁ",
    	"z": "ᛉ",
    	"s": "ᛊ",
    	"t": "ᛏ",
    	"b": "ᛒ",
    	"e": "ᛖ",
    	"m": "ᛗ",
    	"l": "ᛚ",
    	"d": "ᛞ",
    	"o": "ᚩ",
    	"ô": "ᛟ",
    	" ": "᛫",
    	"û": "ᚢᚢ",
    	 "â": "ᚨᚨ",
    	"î": "ᛁᛁ",
    	"ê" : "ᛖᛖ"
    }
    
    
    fdic2 = {
    	"kh": "ᛣ",
    	"th": "ᛐ",
    	"sh": "ᛋ",
    	"; ": "; ",
    	", ": ", "
    }
    			
    def futhark(s):
    	t = ""
    	i = 0
    	while i < len(s):
    		if s[i:i+2] in fdic2:
    			t = t + fdic2.get(s[i:i+2])
    			i = i + 2
    		elif s[i:i+1] in fdic1:
    			t = t +fdic1.get(s[i:i+1])
    			i = i + 1
    	return t
    
    def transliterate(entry):			
    	for i in range(len(entry.words[Turgan])):
    		entry.words[Turgan][i] = unfuthark(entry.words[Turgan][i])
    	return entry
    
    def English_pronoun(person, number, gender):
    	if person=='3':
    		person = person + gender
    	
    	pronoun = from_table(person, number,[
    	
    								[	'sg.',					'pl.'				],
    	
    					['1',			'I',					'we'				],
    					['2',			'you {sg.}',		'you {pl.}'	],
    					['3m.',		'he',					'they {m.}'	],
    					['3f.',		'she',				'they {f.}'		],
    					['3n.',		'it',					'they {n.}'	],
    					
    	])			
    	return pronoun
    	
    def Turgan_pronoun(person, number, gender):
    	if person=='3':
    		person = person + gender
    	
    	pronoun = from_table(person, number,[
    	
    								[	'sg.',					'pl.'		],
    	
    					['1',			'ik',					'bês'	],
    					['2',			'du',					'lus'		],
    					['3m.',		'is',					'ês'		],
    					['3n.',		'ita',					'ila'		],
    					['3f.',		'si',					'ilos'	],
    					
    	])			
    	return pronoun
    	
    
    
    def English_noun(w,num,case, mark_case):
    	if num == 'pl.':
    		if has(w,'pl.'):
    			w = what_is(w,'pl.')
    		elif w in ['Dwarf', 'dwarf']:
    			w = w[:-1]+'ves'
    		else:
    			if ends_with(w,'y') and not ends_with(w, sequence(['a','e','i','o','u'], 'y')):
    				w = w[:-1] + 'ies'
    			elif ends_with(w, 's','x','z','sh','ch','o'):
    				w = w + 'es'
    			else:
    				w = w + 's'
    	if mark_case:
    		return w + ' {'+case+'}'
    	else:
    		return w
    
    def replace_last(string, substring, substitute):
    	n = string.rfind(substring)
    	return string[:n]+substitute+string[n+len(substring):]
    
    def get_vowels(s):
    	t = ""
    	for letter in s:
    		if letter in ['a', 'e', 'i', 'o', 'u', 'â', 'ê', 'î', 'ô', 'û']:
    			t = t + letter
    	return t
    
    def get_gender(w):
    	if '!' in brackets[w]:      # Strong noun
    		if ends_with(w,'us'):	# Masculine
    			return 'm.'
    		elif ends_with(w,'a'):
    			return 'f.'
    		else:
    			return 'n.'
    	else:
    		if ends_with(w,'a'):
    			return 'm.'
    		elif ends_with(w,'ê'):
    			return 'f.'
    		elif 'f.' in brackets[w]:
    			return 'f.'
    		else:
    			return 'n.'
    
    def Turgan_noun(w,num,case):
    	
    	if '!' in brackets[w]:      # Strong noun
    		if ends_with(w,'us'):	# Masculine
    			return w[:-2] + from_table(case, num,[
    		
    							[	'sg.',			'pl.'],
    		
    			['nom.',		'us',			'lus'],
    			['obj.',			'ô',			'uns'],
    			['gen.',			'ôs',			'ibê'],
    		
    			])
    			
    		elif ends_with(w,'a'):		# Feminine			
    					return w[:-1] + from_table(case, num,[
    		
    							[	'sg.',			'pl.'],
    		
    			['nom.',		'a',			'ôns'],
    			['obj.',			'a',			'ôns'],
    			['gen.',			'ôs',			'ôns'],
    		
    			])
    	
    		else :								#Neuter	
    			return w + from_table(case, num,[
    		
    							[	'sg.',			'pl.'],
    		
    			['nom.',		'',				'a'],
    			['obj.',			'',				'a'],
    			['gen.',			'is',			'ê'],
    		
    			])
    
    	else:								#Weak or broken noun
    		ending = w[-1:]
    		stem = w[:-1]
    		suffix = ' — '
    		if ending == 'a':
    			suffix = from_table(case, num,[
    		
    							[	'sg.',			'pl.'],
    		
    			['nom.',		'a',			'ans'],
    			['obj.',			'an',			'ans'],
    			['gen.',			'ins',			'ans'],
    		
    			])
    			
    			if num == 'pl.' and '*' in brackets[w]:
    				if starts_with(w, 'u', 'û'):
    					stem = replace_last(stem, 'a', 'â')
    				else :
    					m = -1
    					if ends_with(stem, 'kh', 'th', 'sh'):
    						m = -2
    					stem = stem.replace('u', 'a')
    					stem = stem[:m]+'â'+stem[m:]
    			
    		if ending == 'ô':
    				if 'f.' in brackets[w]:
    					suffix = from_table(case, num,[
    			
    									[	'sg.',			'pl.'],
    	
    					['nom.',		'ô',			'ôns'],
    					['obj.',			'ôn',			'ôns'],
    					['gen.',			'ônis',		'ôns']
    	
    					])		
    					
    				else:
    					suffix = from_table(case, num,[
    			
    									[	'sg.',			'pl.'],
    	
    					['nom.',		'ô',			'ôna'],
    					['obj.',			'ôn',			'ôna'],
    					['gen.',			'ônis',		'ôna']
    	
    					])				
    					
    				if num == 'pl.' and '*' in brackets[w]:
    					signature_vowels = get_vowels(stem)
    					m = -2 if  ends_with(stem, 'kh', 'th', 'sh') else -1
    					if signature_vowels == 'a':
    						stem = stem[:m]+'u'+stem[m:]
    					elif signature_vowels == 'ea':
    						stem = stem.replace('a', 'â')
    					elif signature_vowels == 'u':
    						stem = stem[:m]+'û'+stem[m:]
    					elif signature_vowels == 'oo':
    						stem = stem[0] + 'a' + stem[2] + 'â' + stem[4]
    					elif signature_vowels == 'oi':
    						stem = stem.replace('i', 'î')
    		
    		if ending == 'ê':
    			suffix = from_table(case, num,[
    			
    									[	'sg.',			'pl.'],
    	
    					['nom.',		'ê',			' — '],
    					['obj.',			'ên',			' — '],
    					['gen.',			'êns',		' — ']
    	
    					])				
    
    	return stem + suffix
    	
    
    def definite_article(n, g, case):
    	 
    	return from_table(case+' '+n, g, [
    	
    						[	'm.',			'n.',			'f.'		],
    	
    	['nom. sg.',		'sa',			'dat',		'sa'		],
    	['obj. sg.',		'dan',		'dat',		'da'		],
    
    	['nom. pl.',		'dai',		'da',			'dos'	],
    	['obj. pl.',			'dans',		'da',			'dos'	],
    
    	])
    
    def Turgan_adjective(w, n, g, case):
    	if 'no sg.' in brackets[w]:
    		w = w[:-3]
    	else:
    		w = w[:-1]
    	
    	row = case if n == 'sg.' else 'pl.'
    	
    	return w + from_table(row, g, [
    	
    				[	'm.',		'n.',		'f.'		],
    
    	['nom.',	'a',		'ô',		'a'		],
    	['obj.',		'an',		'ôn',		'ôn'		],
    	['gen.',		'ins',		'ônis',	'ônis'	],
    
    	['pl.',		'ans',	'ôna',	'ôns'	],
    
    	])
    
    def strong_preterite(s, n, v, v1, v2, p, p1, p2):
    	if n == 'sg.':
    		s = s[0]+s[1:].replace(v, v1)
    		if s[0] == p:
    			s = p1 + s[1:]
    	else:
    		s = s[0]+s[1:].replace(v, v2)
    		if s[0] == p:
    			s = p2 + s[1:]
    	return s
    
    def Turgan_verb(vb, p, n, t):
    	if t == 'pres.':
    		trimmed = vb[:-1]
    		if n == '2' or (n == '3' and n == 'sg.'):
    			if '3' in brackets[vb]:
    				trimmed = trimmed + 'i'
    			elif not '2' in brackets[vb]:
    				trimmed = trimmed[:-1] + 'i'
    		return trimmed + from_table(p, n, [
    		
    					[	'sg.',			'pl.'	],
    					
    			['1',		'',				'm'	],
    			['2',		's',			'th'	],
    			['3',		'th',			'nd'	],
    			
    			])
    	else:     # Preterite
    		trimmed = vb
    		if '1' in brackets[vb]:
    			trimmed =  vb[:-3]+'i'
    		if '2' in brackets[vb]:
    			trimmed = vb[:-1]
    		if '3' in brackets[vb]:
    			trimmed = vb[:-1] + 'i'
    		if trimmed != vb:
    			return trimmed + from_table(p, n, [
    					[	'sg.',			'pl.'			],
    
    			['1',		'da',			'dêdum'	],
    			['2',		'dês',		'dêduth'	],
    			['3',		'da',			'dêdun'	],
    			
    			])
    		trimmed = vb[:-2]		
    		if 'I' in brackets[vb]:
    			trimmed = strong_preterite(trimmed, n, 'ê', 'ai', 'i', 'e', 'a', 'i')
    		if 'II' in brackets[vb]:
    			trimmed = strong_preterite(trimmed, n, 'û', 'ô', 'u', 'u', 'u', 'u')
    		if 'III' in brackets[vb]:
    			trimmed = strong_preterite(trimmed, n, 'i', 'a', 'u', 'i', 'a', 'u')
    		if 'IV' in brackets[vb]:
    			trimmed = strong_preterite(trimmed, n, 'i', 'e', 'ê', 'i', 'a', 'e')
    		if 'VI' in brackets[vb]:
    			trimmed = strong_preterite(trimmed, n, 'a', 'ô', 'ô', 'a', 'u', 'u')
    		if 'VIIa' in brackets[vb]:
    			if trimmed[0] in ['a', 'e', 'i', 'u']:
    				trimmed = trimmed[1:]
    			trimmed = trimmed[0]+'ai'+trimmed
    		if 'VIIb' in brackets[vb]:
    			if trimmed[0] in ['a', 'e', 'i', 'u']:
    				trimmed = trimmed[1:]
    			trimmed = trimmed[0]+'ai'+trimmed.replace('ê','ô')
    		return trimmed + from_table(p, n, [
    		
    				[		'sg.',			'pl.'	],
    
    			['1',		'',				'um'	],
    			['2',		'',				'uth'	],
    			['3',		'',				'un'	],
    			
    			])
    		
    
    def English_verb(verb, person, number, tense):
    	trimmed_verb = verb
    	if verb[:3] == 'to ':
    		trimmed_verb = verb[3:]
    	space = trimmed_verb.find(' ') 
    	if space == -1:
    		head = trimmed_verb
    		tail = ''
    	else:
    		head = trimmed_verb[:space]
    		tail = trimmed_verb[space:]
            
    	if tense == 'pres.':
    		if person == '3' and number == 'sg.':
    			if head == 'have':
    				head = 'ha'
    			if ends_with(head,'y') and not ends_with(head, sequence(['a','e','i','o','u'], 'y')):
    				head = head[:-1] + 'ies'
    			elif ends_with(head, 's','x','z','sh','ch','o'):
    				head = head + 'es'
    			else:
    				head = head + 's'
    	else: #We do the preterite. 
    		if has(verb,'pret.'):
    			head = what_is(verb,'pret.')
    		elif head == 'be':
    			if number == 'sg.' and person == '3rd':
    				head = 'was'
    			else:
    				head = 'were'
    		else:
    			if ends_with(head,'y') and not ends_with(head, sequence(['a','e','i','o','u'], 'y')):
    				head = head[:-1] + 'i'
    			if head[-1] == 'e':
    				head = head + 'd'
    			else:
    				head = head + 'ed'
    				
    	return head + tail
    
    
    def to_do(p,n,t):
    	if t == 'pret.':
    		return 'did'
    	else:
    		return 'does' if p == '3' and n == 'sg.' else 'do'
    
    def indefinite_article(w,n):
    	if n == 'pl.':
    		return ' '
    	else:
    		return ' an ' if starts_with(w,'a','e','i','o','u')  else ' a '
    
    def to_be(p,n,t):
    	return from_table(p, t+' '+n, [
    			[	'pres. sg.',	'pres. pl.',	'pret. sg.',	'pret. pl.'	],
    			
    		['1',	'am',			'are',			'was',			'were'		],
    		['2', 'are',			'are',			'were',			'were'		],
    		['3', 'is',				'are',			'was',			'were'		],
    	])
    	
    def wisan(p,n,t):
    	return from_table(p, t+' '+n,  [
    			[	'pres. sg.',	'pres. pl.',	'pret. sg.',	'pret. pl.'		],
    			
    		['1',	'im',				'silum',		'bas',			'bêsum'		],
    		['2', 'is',				'siluth',		'bast',			'bêsuth'		],
    		['3', 'ist',				'sind',			'bas',			'bêsun'		],
    	])
    
    def sentence_from(tenses, sentence_structures):
    	sentence_structure = random.choice(sentence_structures)
    	note(sentence_structure)
    	tense = random.choice(tenses)
    	if sentence_structure[0] == 'P':
    		person = random.choice(['1', '2', '3'])
    		gender = random.choice(['m.','f.', 'n.'])
    	else:
    		agent = fetch('p')
    	if sentence_structure[0] == 'Q':
    		format[English] = standard_format('', True, '?')
    		if question_language == English:
    			format[Turgan] = standard_format('', True, '?')
    	number = random.choice(['sg.', 'pl.'])
    	if sentence_structure.find('A') != -1:
    		adjective = fetch('a')
    	if sentence_structure.find('G') != -1:
    		possessor = fetch('p')
    	possessor_number = random.choice(['sg.', 'pl.'])
    	if sentence_structure == 'SVO':
    		verb = fetch('v')
    		grammar(English,  'the ', [agent, English_noun, number, '', ''] , ' ', [verb, English_verb, '3', number, tense] ,' the ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan,  [definite_article, number, [agent, get_gender], 'nom.'], ' ', [agent, Turgan_noun, number, 'nom.'] , ' ', [verb, Turgan_verb, '3', number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    	elif sentence_structure == 'SVOA':
    		verb = fetch('v')
    		grammar(English,  'the ', [agent, English_noun, number, '', ''] , ' ', [verb, English_verb, '3', number, tense] ,' the ', [adjective], ' ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan,  [definite_article, number, [agent, get_gender], 'nom.'], ' ', [agent, Turgan_noun, number, 'nom.'] , ' ', [verb, Turgan_verb, '3', number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'], ' ', [adjective, Turgan_adjective, noun_number, [noun, get_gender], 'obj.'])	
    	elif sentence_structure == 'SV':
    		verb = fetch('vi')
    		grammar(English,  'the ', [agent, English_noun, number, '', ''] , ' ', [verb, English_verb, '3', number, tense])
    		grammar(Turgan,   [definite_article, number, [agent, get_gender], 'nom.'] , ' ', [agent, Turgan_noun, number, 'nom.'] , ' ', [verb, Turgan_verb, '3', number, tense])
    	elif sentence_structure == 'SAV':
    		verb = fetch('vi')
    		grammar(English,  'the ', [adjective], ' ', [agent, English_noun, number, '', ''] , ' ', [verb, English_verb, '3', number, tense])
    		grammar(Turgan,   [definite_article, number, [agent, get_gender], 'nom.'] , ' ', [agent, Turgan_noun, number, 'nom.'] , ' ', [adjective, Turgan_adjective, number, [agent, get_gender], 'nom.'] , ' ', [verb, Turgan_verb, '3', number, tense])
    	elif sentence_structure == 'PVO':
    		verb = fetch('v')
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [verb, English_verb, person, number, tense] ,' the ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender], ' ', [verb, Turgan_verb, person, number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    	elif sentence_structure == 'PVOG':
    		verb = fetch('v')
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [verb, English_verb, person, number, tense] ,' the ', [noun, English_noun, noun_number, '', ''] , ' of the ', [possessor, English_noun, possessor_number, '', ''])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender], ' ', [verb, Turgan_verb, person, number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'], ' ', [possessor, Turgan_noun, possessor_number, 'gen.'])
    	elif sentence_structure == 'PV':
    		verb = fetch('vi')
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [verb, English_verb, person, number, tense])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender] , ' ', [verb, Turgan_verb, person, number, tense])
    	elif sentence_structure == 'SnV':
    		verb = fetch('vi')
    		grammar(English,  'the ', [agent, English_noun, number, '', ''] , ' ', [to_do, '3', number, tense] ,' not ', [verb, English_verb, '3', 'pl.', 'pres.'])
    		grammar(Turgan,   [definite_article, number, [agent, get_gender], 'nom.'] , ' ', [agent, Turgan_noun, number, 'nom.'] , ' ni ', [verb, Turgan_verb, '3', number, tense])
    	elif sentence_structure == 'SnVO':
    		verb = fetch('v')
    		grammar(English,  'the ', [agent, English_noun, number, '', ''] , ' ', [to_do, '3', number, tense] ,' not ', [verb, English_verb, '3', 'pl.', 'pres.'] ,' the ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan,  [definite_article, number, [agent, get_gender], 'nom.'], ' ', [agent, Turgan_noun, number, 'nom.'] , ' ni ', [verb, Turgan_verb, '3', number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    	elif sentence_structure == 'PnV':
    		verb = fetch('vi')
    		grammar(English,  [English_pronoun, person, number,  gender], ' ', [to_do, person, number, tense] ,' not ', [verb, English_verb,  '3', 'pl.', 'pres.'])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender] , ' ni ', [verb, Turgan_verb, person, number, tense])
    	elif sentence_structure == 'PnVO':
    		verb = fetch('v')
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [to_do, person, number, tense] ,' not ', [verb, English_verb,  '3', 'pl.', 'pres.'] ,' the ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender], ' ni ', [verb, Turgan_verb, person, number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    	elif sentence_structure == 'PnVOG':
    		verb = fetch('v')
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [to_do, person, number, tense] ,' not ', [verb, English_verb,  '3', 'pl.', 'pres.'] ,' the ', [noun, English_noun, noun_number, '', ''] , ' of the ', [possessor, English_noun, possessor_number, '', ''])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender], ' ni ', [verb, Turgan_verb, person, number, tense] , ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'], ' ', [possessor, Turgan_noun, possessor_number, 'gen.'])
    	elif sentence_structure == 'QVO':
    		inter = fetch('q1')
    		verb = fetch('v')
    		grammar(English, [inter], ' ',[verb, English_verb, '3', 'sg.', tense] ,' the ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan, [inter], ' ',[verb, Turgan_verb, '3', 'sg.', tense], ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    	elif sentence_structure == 'QV':
    		inter = fetch('q1')
    		verb = fetch('vi')
    		grammar(English, [inter], ' ',[verb, English_verb, '3', 'sg.', tense])
    		grammar(Turgan, [inter], ' ',[verb, Turgan_verb, '3', 'sg.', tense])
    	elif sentence_structure == 'QVSO':
    		inter = fetch('q2')
    		verb = fetch('v')
    		grammar(English, [inter], ' ',[to_do, '3', number , tense], ' the ', [agent, English_noun, number, '', ''], ' ', [verb, English_verb, '3', 'pl.', 'pres.'],' the ', [noun, English_noun, noun_number, '', ''])
    		grammar(Turgan, [inter], ' ',[verb, Turgan_verb, '3', number , tense], ' ', [definite_article, number, [agent, get_gender], 'nom.'] , ' ', [agent, Turgan_noun, number, 'nom.'], ' ', [definite_article, number, [noun, get_gender], 'obj.'], ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    	elif sentence_structure == 'QVS':
    		inter = fetch('q2')
    		verb = fetch('vi')
    		grammar(English, [inter], ' ',[to_do, '3', number, tense], ' the ', [agent, English_noun, number, '', ''], ' ', [verb, English_verb, '3', 'pl.', 'pres.'])
    		grammar(Turgan, [inter], ' ',[verb, Turgan_verb, '3', number, tense], ' ', [definite_article, number, [agent, get_gender], 'nom.'] , ' ', [agent, Turgan_noun, number, 'nom.'])	
    	elif sentence_structure == 'PBO':
    		agent = fetch('p')
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [to_be, person, number, tense] , [agent, indefinite_article, number],  [agent, English_noun, number, '', ''])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender], ' ', [wisan, person, number, tense] , ' ', [agent, Turgan_noun, number, 'nom.'])
    	elif sentence_structure == 'PBA':
    		grammar(English,  [English_pronoun, person, number,  gender] , ' ', [to_be, person, number, tense] , ' ',  [adjective])
    		grammar(Turgan,  [Turgan_pronoun, person, number,  gender], ' ', [wisan, person, number, tense] , ' ', [adjective, Turgan_adjective, number, gender, 'nom.'])
    	elif sentence_structure == 'SBA':
    		grammar(English,   'the ', [noun, English_noun, number, '', ''] , ' ', [to_be, '3', number, tense] , ' ', [adjective])
    		grammar(Turgan,  [definite_article, number, [noun, get_gender], 'nom.'], ' ', [noun, Turgan_noun, number, 'nom.'] ,  ' ', [wisan, '3', number, tense] , ' ', [adjective, Turgan_adjective, number, [noun, get_gender],'nom.'])
    
    	
    
    		
    noun = fetch('n')
    noun_number = random.choice(['sg.', 'pl.'])
    if 'no pl.' in noun.brackets:
    	noun_number = 'sg.'
    
    if topic_directive in ['D', 'G', 'Adj', 'N', 'P']:
    	format[Turgan] = standard_format('', False, '')
    	format[English] = standard_format('', False, '')
    else :
    	format[English] = standard_format('', True, '.')
    	if (not topic_directive in  ['V', 'V2']) and question_language == Turgan and questions == 'written':		
    		format[Turgan] = futhark
    	else:
    		format[Turgan] = standard_format('', True, '.')
    directive = '[T]'
    
    if topic_directive in ['D', 'G', 'Adj']:
    	case = random.choice(['nom.', 'obj.'])
    if topic_directive == 'N':	
    	case = random.choice(['nom.', 'obj.', 'gen.'])
    
    if topic_directive == 'N':
    	grammar(English,  [noun, English_noun, noun_number, case, 'Y'])
    	grammar(Turgan,  [noun, Turgan_noun, noun_number, case])
    elif topic_directive == 'D':	
    	grammar(English,  'the ', [noun, English_noun, noun_number, case, 'Y'])
    	grammar(Turgan,  [definite_article, noun_number, [noun, get_gender], case] , ' ', [noun, Turgan_noun, noun_number, case])
    elif topic_directive == 'G':
    	possessor = fetch('p')
    	possessor_number = random.choice(['sg.', 'pl.'])
    	grammar(English,  'the ', [noun, English_noun, noun_number, case, 'Y'], ' of the ', [possessor, English_noun, noun_number, case, ''])
    	grammar(Turgan,  [definite_article, noun_number, [noun, get_gender], case] , ' ', [noun, Turgan_noun, noun_number, case], ' ', [possessor, Turgan_noun, possessor_number, 'gen.'])	
    elif topic_directive == 'Adj':
    	adjective = fetch('a')
    	if 'no sg.' in adjective.brackets:
    		noun_number = 'pl.'
    	grammar(English,  'the ', [adjective], ' ', [noun, English_noun, noun_number, case, 'Y'])
    	grammar(Turgan,  [definite_article, noun_number, [noun, get_gender], case] , ' ', [noun, Turgan_noun, noun_number, case] , ' ', [adjective, Turgan_adjective, noun_number, [noun, get_gender], case])
    elif topic_directive == 'P':
    	preposition = fetch('pr')
    	grammar(English,  [preposition] ,  ' the ', [noun, English_noun, noun_number, '', ''])
    	if '+ gen.' in preposition.brackets:
    		grammar(Turgan,  [preposition], ' ', [noun, Turgan_noun, noun_number, 'gen.'])
    	else:	
    		grammar(Turgan,  [preposition], ' ', [definite_article, noun_number, [noun, get_gender], 'obj.'] , ' ', [noun, Turgan_noun, noun_number, 'obj.'])
    elif topic_directive == 'V':
    	sentence_from(['pres.'],['SVO', 'SV'])
    elif topic_directive == 'V2':
    	sentence_from(['pres.'],['PVO', 'PV'])
    elif topic_directive == 'Pret' :
    	sentence_from(['pret.'],['SVO', 'SV', 'PVO', 'PV'])
    elif topic_directive == 'Prac 1' :
    	sentence_from(['pres.', 'pret.'],['PVOG', 'SVOA',  'SAV', 'SV', 'SVO', 'PVO', 'PV'])
    elif topic_directive == 'B':
    	sentence_from(['pres.', 'pret.'],['PBO', 'SBA', 'PBA'])
    elif topic_directive == 'Neg':
    	sentence_from(['pres.', 'pret.'],[ 'PnVOG', 'PnVO', 'PnV','SnVO','SnV'])
    elif topic_directive == 'Q':
    	sentence_from(['pres.', 'pret.'],['QVO', 'QV', 'QVSO', 'QVS'])
    elif topic_directive == 'Prac 2' :
    	sentence_from(['pres.', 'pret.'],['QVO', 'QV', 'QVSO', 'QVS', 'PBO', 'SBA', 'PBA', 'PnVOG', 'PnVO', 'PnV','SnVO','SnV', 'PVOG', 'SVOA',  'SAV', 'SV', 'SVO', 'PVO', 'PV'])
    pass

except Exception as err:
    _error_report = str(err)
    _error_line = ''
    for tuple in traceback.walk_tb(sys.exc_info()[-1]):
        _error_line = str(tuple[1]) + ', ' + _error_line

finally:

    with io.open("pytopa.rsc", "w", encoding="utf-8") as file:
        file.write(directive+"\n")
        file.write(result[0]+"\n")
        file.write(result[1]+"\n")
        file.write(_error_report+"\n")
        file.write(_error_line+"\n")
        file.write(_notes+"\n")
        file.write(', '.join([str(i) for i in _fetched])+"\n")
